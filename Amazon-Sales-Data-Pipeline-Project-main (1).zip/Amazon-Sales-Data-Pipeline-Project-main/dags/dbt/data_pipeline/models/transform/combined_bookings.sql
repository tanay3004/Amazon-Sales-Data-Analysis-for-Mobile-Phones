{{ dbt_utils.union_relations(
    relations=[ref('bookings_1'), ref('bookings_2')]
)}}